angular.module('greenRobotics').directive('signupView', function() {
    return {
        restrict: 'A',
        templateUrl: 'app/views/signup_1.html'
    };
});


