angular.module('greenRobotics').directive('signupContinue', function() {
    return {
        restrict: 'A',
        templateUrl: 'app/views/signupContinue.html'
    };
});