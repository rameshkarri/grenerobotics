angular.module('greenRobotics').directive('enterpriselistdetailsview', function() {
    return {
        restrict: 'A',
        templateUrl: 'app/views/enterpriselistdetails.html'
    };
});


