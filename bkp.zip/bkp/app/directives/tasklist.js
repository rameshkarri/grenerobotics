angular.module('greenRobotics').directive('tasklistview', function() {
    return {
        restrict: 'A',
        templateUrl: 'app/views/taskList.html'
    };
});


